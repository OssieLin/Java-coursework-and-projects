import java.util.*; 
public class tryout_1{ 
public static void main(String args[]){ 
  System.out.println("I've always been obsessed in technology.");
  System.out.println("It was indeed intriguing.");
  System.out.println("Building my own tic-tac-toe game.");
  System.out.println("I wanna use my coding ability to benefit the world.");
  System.out.println("Passion can drive me crazy.");
  System.out.println("Java is somethinggg.");
  System.out.println("All in all, I'll try my best in the course.");
 }//main()
}//class
